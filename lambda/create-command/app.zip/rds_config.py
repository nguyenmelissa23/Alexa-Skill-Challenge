#config file containing credentials for rds mysql instance
db_username = "GitWatchAdmin"
db_password = "81aQ5LKK44p7"
db_name = "gitwatchdb"
db_host = "gitwachdb.c0tsrytvgqif.us-west-1.rds.amazonaws.com"